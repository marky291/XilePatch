This is the default skin used in older versions of Thor Patcher.
It has been upgrade to support 2.6